var WebWorkerThreads = require('bindings')('WebWorkerThreads');
 
module.exports = WebWorkerThreads;
