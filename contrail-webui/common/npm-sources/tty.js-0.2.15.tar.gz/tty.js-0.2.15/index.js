module.exports = require('./lib/tty.js');
