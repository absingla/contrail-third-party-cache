var convert = require('./convert'),
    func = convert('isBuffer', require('../isBuffer'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
