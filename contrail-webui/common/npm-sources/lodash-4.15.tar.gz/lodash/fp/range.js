var convert = require('./convert'),
    func = convert('range', require('../range'));

func.placeholder = require('./placeholder');
module.exports = func;
