var convert = require('./convert'),
    func = convert('stubArray', require('../stubArray'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
