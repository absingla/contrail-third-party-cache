var convert = require('./convert'),
    func = convert('endsWith', require('../endsWith'));

func.placeholder = require('./placeholder');
module.exports = func;
