var convert = require('./convert'),
    func = convert('toSafeInteger', require('../toSafeInteger'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
