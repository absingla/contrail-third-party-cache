var convert = require('./convert'),
    func = convert('forIn', require('../forIn'));

func.placeholder = require('./placeholder');
module.exports = func;
